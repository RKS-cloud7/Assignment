// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    initializePage();
    updateCartCount();
    setupEventListeners();
    populateMenuItems();
    setMinimumDate();
});

function initializePage() {
    // Show home section by default
    showSection('home');
    
    // Setup mobile menu
    const menuBtn = document.querySelector('.mobile-menu-btn');
    if (menuBtn) {
        menuBtn.addEventListener('click', toggleMobileMenu);
    }

    // Setup header shrink on scroll
    window.addEventListener('scroll', function() {
        const header = document.querySelector('header');
        if (window.scrollY > 40) {
            header.classList.add('shrink');
        } else {
            header.classList.remove('shrink');
        }
    });

    // Cookie box
    if (!localStorage.getItem('cookiesAccepted')) {
        const cookieBox = document.getElementById('cookie-box');
        if (cookieBox) cookieBox.style.display = 'block';
    }
}

function setupEventListeners() {
    // Forms
    const reservationForm = document.getElementById('reservation-form');
    if (reservationForm) {
        reservationForm.addEventListener('submit', submitReservation);
    }

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', submitContact);
    }

    const feedbackForm = document.getElementById('feedback-form');
    if (feedbackForm) {
        feedbackForm.addEventListener('submit', submitFeedback);
    }

    // Menu filtering
    const spiceSelect = document.getElementById('spice-level');
    if (spiceSelect) {
        spiceSelect.addEventListener('change', function() {
            applySpiceFilter(this.value);
        });
    }
}

// ==================== SECTION NAVIGATION ====================
function showSection(sectionName) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });

    // Show selected section
    const section = document.getElementById(sectionName + '-section');
    if (section) {
        section.classList.add('active');
        window.scrollTo(0, 0);
    }

    // Update nav links
    document.querySelectorAll('nav a').forEach(link => {
        link.classList.remove('active');
    });
}

function toggleMobileMenu() {
    const navMenu = document.querySelector('nav ul');
    if (navMenu) {
        navMenu.classList.toggle('open');
    }
}

// ==================== MENU & CART MANAGEMENT ====================
const MENU_DATA = {
    starters: [
        { id: 1, title: 'Samosa', price: 5.99, spice: 'medium', image: 'images/samosa.jpg', desc: 'Crispy pastry filled with spiced potatoes and peas' },
        { id: 2, title: 'Vegetable Pakora', price: 6.99, spice: 'mild', image: 'images/pakora.jpg', desc: 'Assorted vegetables dipped in chickpea batter' },
        { id: 3, title: 'Paneer Tikka', price: 8.99, spice: 'medium', image: 'images/paneer-tikka.jpg', desc: 'Grilled cottage cheese cubes marinated in spices' },
        { id: 4, title: 'Chicken Tikka', price: 9.99, spice: 'hot', image: 'images/chicken-tikka.jpg', desc: 'Spicy grilled chicken pieces' },
        { id: 5, title: 'Aloo Tikki', price: 5.49, spice: 'mild', image: 'images/aloo-tikki.jpg', desc: 'Potato patties served with chutney' },
        { id: 6, title: 'Dahi Puri', price: 6.49, spice: 'mild', image: 'images/dahi-puri.jpg', desc: 'Mini puris filled with yogurt and chutneys' },
        { id: 7, title: 'Chilli Paneer', price: 8.99, spice: 'hot', image: 'images/chilli-paneer.jpg', desc: 'Paneer tossed in spicy Indo-Chinese sauce' },
        { id: 8, title: 'Fish Amritsari', price: 10.99, spice: 'medium', image: 'images/fish-amritsari.jpg', desc: 'Spiced fried fish from Punjab' }
    ],
    vegetarian: [
        { id: 9, title: 'Paneer Butter Masala', price: 12.99, spice: 'medium', image: 'images/paneer-butter-masala.jpg', desc: 'Cottage cheese in rich tomato and cream sauce' },
        { id: 10, title: 'Dal Makhani', price: 10.99, spice: 'mild', image: 'images/dal-makhani.jpg', desc: 'Slow-cooked black lentils in creamy sauce' },
        { id: 11, title: 'Chana Masala', price: 11.49, spice: 'medium', image: 'images/chana-masala.jpg', desc: 'Chickpeas cooked in spicy tomato gravy' },
        { id: 12, title: 'Palak Paneer', price: 12.49, spice: 'mild', image: 'images/palak-paneer.jpg', desc: 'Paneer cubes in creamy spinach sauce' },
        { id: 13, title: 'Veg Korma', price: 11.99, spice: 'mild', image: 'images/veg-korma.jpg', desc: 'Mixed vegetables in mild creamy sauce' },
        { id: 14, title: 'Bhindi Masala', price: 10.99, spice: 'medium', image: 'images/bhindi-masala.jpg', desc: 'Okra cooked with onions and spices' },
        { id: 15, title: 'Malai Kofta', price: 12.99, spice: 'mild', image: 'images/malai-kofta.jpg', desc: 'Vegetable balls in creamy sauce' }
    ],
    'non-vegetarian': [
        { id: 16, title: 'Butter Chicken', price: 13.99, spice: 'medium', image: 'images/butter-chicken.jpg', desc: 'Chicken cooked in creamy tomato sauce' },
        { id: 17, title: 'Chicken Curry', price: 12.99, spice: 'hot', image: 'images/chicken-curry.jpg', desc: 'Chicken pieces in spicy curry sauce' },
        { id: 18, title: 'Rogan Josh', price: 15.99, spice: 'hot', image: 'images/rogan-josh.jpg', desc: 'Spicy lamb curry from Kashmir' },
        { id: 19, title: 'Fish Curry', price: 14.49, spice: 'medium', image: 'images/fish-curry.jpg', desc: 'Fish cooked in tangy tomato gravy' },
        { id: 20, title: 'Prawn Masala', price: 16.49, spice: 'hot', image: 'images/prawn-masala.jpg', desc: 'Prawns cooked in spicy masala sauce' },
        { id: 21, title: 'Egg Curry', price: 10.99, spice: 'medium', image: 'images/egg-curry.jpg', desc: 'Boiled eggs in spicy tomato gravy' }
    ],
    'rice-biryani': [
        { id: 22, title: 'Veg Biryani', price: 11.99, spice: 'medium', image: 'images/veg-biryani.jpg', desc: 'Fragrant rice cooked with vegetables' },
        { id: 23, title: 'Chicken Biryani', price: 13.99, spice: 'hot', image: 'images/chicken-biryani.jpg', desc: 'Spicy rice with chicken and aromatic spices' },
        { id: 24, title: 'Mutton Biryani', price: 15.99, spice: 'hot', image: 'images/mutton-biryani.jpg', desc: 'Rich biryani with tender mutton' },
        { id: 25, title: 'Jeera Rice', price: 7.99, spice: 'mild', image: 'images/jeera-rice.jpg', desc: 'Basmati rice flavored with cumin seeds' },
        { id: 26, title: 'Lemon Rice', price: 8.49, spice: 'mild', image: 'images/lemon-rice.jpg', desc: 'South Indian rice with lemon' }
    ],
    breads: [
        { id: 27, title: 'Naan', price: 3.99, spice: 'mild', image: 'images/naan.jpg', desc: 'Soft leavened bread baked in tandoor' },
        { id: 28, title: 'Garlic Naan', price: 4.49, spice: 'mild', image: 'images/garlic-naan.jpg', desc: 'Naan topped with garlic and butter' },
        { id: 29, title: 'Roti', price: 2.99, spice: 'mild', image: 'images/roti.jpg', desc: 'Whole wheat flatbread' },
        { id: 30, title: 'Lachha Paratha', price: 4.99, spice: 'mild', image: 'images/lachha-paratha.jpg', desc: 'Layered crispy flatbread' }
    ],
    drinks: [
        { id: 31, title: 'Masala Chai', price: 2.99, spice: 'mild', image: 'images/masala-chai.jpg', desc: 'Spiced Indian tea with milk' },
        { id: 32, title: 'Lassi', price: 3.49, spice: 'mild', image: 'images/lassi.jpg', desc: 'Sweet or salty yogurt drink' },
        { id: 33, title: 'Filter Coffee', price: 2.99, spice: 'mild', image: 'images/filter-coffee.jpg', desc: 'South Indian style strong coffee' },
        { id: 34, title: 'Jaljeera', price: 2.49, spice: 'medium', image: 'images/jaljeera.jpg', desc: 'Refreshing cumin-flavored drink' }
    ],
    desserts: [
        { id: 35, title: 'Gulab Jamun', price: 4.99, spice: 'mild', image: 'images/gulab-jamun.jpg', desc: 'Milk dumplings soaked in sugar syrup' },
        { id: 36, title: 'Rasmalai', price: 5.49, spice: 'mild', image: 'images/rasmalai.jpg', desc: 'Soft cheese balls in sweetened milk' },
        { id: 37, title: 'Jalebi', price: 3.99, spice: 'mild', image: 'images/jalebi.jpg', desc: 'Deep-fried sweet spirals soaked in syrup' },
        { id: 38, title: 'Kheer', price: 4.49, spice: 'mild', image: 'images/kheer.jpg', desc: 'Rice pudding with milk and nuts' },
        { id: 39, title: 'Kulfi', price: 4.99, spice: 'mild', image: 'images/kulfi.jpg', desc: 'Traditional Indian ice cream' }
    ]
};

function populateMenuItems() {
    const container = document.getElementById('menu-items-container');
    if (!container) return;

    let html = '';
    Object.values(MENU_DATA).flat().forEach(item => {
        html += `
            <div class="menu-item" data-spice="${item.spice}" onclick="addToCart(${item.id}, '${item.title}', ${item.price}, '${item.image}')">
                <img src="${item.image}" alt="${item.title}" style="height:200px; object-fit:cover;">
                <div class="item-info">
                    <h3>${item.title}</h3>
                    <p style="color:#666; font-size:0.9rem;">${item.desc}</p>
                </div>
                <span class="item-price" style="padding:0 20px 20px;">$${item.price.toFixed(2)}</span>
            </div>
        `;
    });
    container.innerHTML = html;
}

function filterMenu(button, category) {
    // Update active button
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    button.classList.add('active');

    // Filter items
    const items = document.querySelectorAll('.menu-item');
    items.forEach(item => {
        item.style.display = 'block';
    });

    // Show only category items
    const menuItems = MENU_DATA[category] || [];
    const itemIds = new Set(menuItems.map(item => item.id));
    
    items.forEach(item => {
        const isInCategory = Array.from(menuItems).some(m => {
            const itemTitle = item.querySelector('h3').textContent;
            return m.title === itemTitle;
        });
        if (!isInCategory && category) {
            item.style.display = 'none';
        }
    });
}

function applySpiceFilter(level) {
    const items = document.querySelectorAll('.menu-item');
    items.forEach(item => {
        if (level === 'all') {
            item.style.display = 'block';
        } else {
            item.style.display = item.dataset.spice === level ? 'block' : 'none';
        }
    });
}

// ==================== CART FUNCTIONS ====================
function getCartItems() {
    try {
        return JSON.parse(localStorage.getItem('cartItems')) || [];
    } catch (e) {
        return [];
    }
}

function saveCartItems(items) {
    localStorage.setItem('cartItems', JSON.stringify(items));
}

function updateCartCount() {
    const cart = getCartItems();
    const count = cart.reduce((sum, item) => sum + (item.qty || 1), 0);
    const countEl = document.getElementById('cart-count');
    if (countEl) countEl.textContent = count;
}

function addToCart(id, title, price, image) {
    const cart = getCartItems();
    const existing = cart.find(item => item.title === title);
    
    if (existing) {
        existing.qty = (existing.qty || 1) + 1;
    } else {
        cart.push({ id, title, price, image, qty: 1 });
    }
    
    saveCartItems(cart);
    updateCartCount();
    updateCartDisplay();
    showToast(title + ' added to cart!');
}

function updateCartQuantity(title, qty) {
    const cart = getCartItems();
    const item = cart.find(item => item.title === title);
    if (item) {
        item.qty = qty;
        if (qty <= 0) {
            removeFromCart(title);
        } else {
            saveCartItems(cart);
            updateCartCount();
            updateCartDisplay();
        }
    }
}

function removeFromCart(title) {
    let cart = getCartItems();
    cart = cart.filter(item => item.title !== title);
    saveCartItems(cart);
    updateCartCount();
    updateCartDisplay();
}

function updateCartDisplay() {
    const cart = getCartItems();
    const cartItemsDiv = document.getElementById('cart-items');
    const cartSummary = document.getElementById('cart-summary');
    const cartEmpty = document.getElementById('cart-empty');

    if (!cartItemsDiv) return;

    if (cart.length === 0) {
        cartItemsDiv.innerHTML = '';
        cartEmpty.style.display = 'block';
        cartSummary.style.display = 'none';
        return;
    }

    cartEmpty.style.display = 'none';
    cartSummary.style.display = 'block';

    let html = '';
    let subtotal = 0;

    cart.forEach(item => {
        const total = item.price * item.qty;
        subtotal += total;
        html += `
            <div class="cart-item" style="display:grid; grid-template-columns:100px 1fr 100px; gap:15px; padding:15px; border:1px solid #eee; border-radius:8px; align-items:center; margin-bottom:10px; background:white;">
                <img src="${item.image}" alt="${item.title}" style="width:100px; height:100px; object-fit:cover; border-radius:8px;">
                <div style="display:flex; flex-direction:column; justify-content:space-between;">
                    <h4 style="color:#003366; margin:0;">${item.title}</h4>
                    <span style="color:#666; font-size:0.9rem;">$${item.price.toFixed(2)} each</span>
                    <span style="font-weight:bold; color:#ff5722;">Subtotal: $${total.toFixed(2)}</span>
                </div>
                <div class="quantity-control" style="display:flex; align-items:center; gap:8px; justify-content:flex-end;">
                    <button onclick="updateCartQuantity('${item.title}', ${item.qty - 1})" style="background:#003366; color:white; border:none; width:30px; height:30px; border-radius:50%; cursor:pointer; font-weight:bold;">-</button>
                    <span style="min-width:30px; text-align:center; font-weight:bold;">${item.qty}</span>
                    <button onclick="updateCartQuantity('${item.title}', ${item.qty + 1})" style="background:#003366; color:white; border:none; width:30px; height:30px; border-radius:50%; cursor:pointer; font-weight:bold;">+</button>
                    <button onclick="removeFromCart('${item.title}')" style="background:#8B0000; color:white; border:none; width:30px; height:30px; border-radius:50%; cursor:pointer; font-weight:bold; margin-left:10px;">✕</button>
                </div>
            </div>
        `;
    });

    cartItemsDiv.innerHTML = html;

    // Update summary
    const deliveryFree = subtotal > 50;
    const deliveryCharge = deliveryFree ? 0 : 5;
    const total = subtotal + deliveryCharge;

    document.getElementById('subtotal').textContent = '$' + subtotal.toFixed(2);
    document.getElementById('delivery-charge').textContent = deliveryFree ? 'Free' : '$' + deliveryCharge.toFixed(2);
    document.getElementById('cart-total').textContent = total.toFixed(2);
}

function placeOrder() {
    const cart = getCartItems();
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }

    const cartItemsDiv = document.getElementById('cart-items');
    const cartSummary = document.getElementById('cart-summary');
    const orderSuccess = document.getElementById('order-success');

    cartItemsDiv.innerHTML = '';
    cartSummary.style.display = 'none';

    orderSuccess.style.display = 'block';
    orderSuccess.innerHTML = `
        <div style="background:white; border-radius:10px; padding:40px; text-align:center;">
            <div style="font-size:3rem; margin-bottom:20px;">🎉</div>
            <h2 style="color:#ff5722; margin-bottom:15px;">Order Placed Successfully!</h2>
            <p style="font-size:1.1rem; color:#666; margin-bottom:20px;">Thank you for your order. Your food will be delivered shortly.</p>
            <button onclick="showSection('menu'); localStorage.removeItem('cartItems'); updateCartDisplay(); updateCartCount();" class="btn" style="background:#003366; color:white; padding:12px 30px; border-radius:5px; text-decoration:none; cursor:pointer;">Continue Shopping</button>
        </div>
    `;

    localStorage.removeItem('cartItems');
    updateCartCount();
}

// ==================== FORM SUBMISSIONS ====================
function submitReservation(e) {
    e.preventDefault();

    const name = document.getElementById('res-name').value;
    const email = document.getElementById('res-email').value;
    const date = document.getElementById('res-date').value;
    const time = document.getElementById('res-time').value;
    const guests = document.getElementById('res-guests').value;

    if (!name || !email || !date || !time || !guests) {
        showToast('Please fill in all fields');
        return;
    }

    // Save to localStorage
    const reservation = { name, email, date, time, guests, timestamp: new Date().toISOString() };
    const reservations = JSON.parse(localStorage.getItem('reservations') || '[]');
    reservations.push(reservation);
    localStorage.setItem('reservations', JSON.stringify(reservations));

    // Show success
    document.getElementById('reservation-form').style.display = 'none';
    document.getElementById('reservation-success').style.display = 'block';

    showToast('Reservation booked successfully!');

    setTimeout(() => {
        document.getElementById('reservation-form').style.display = 'block';
        document.getElementById('reservation-success').style.display = 'none';
        document.getElementById('reservation-form').reset();
    }, 3000);
}

function submitContact(e) {
    e.preventDefault();

    const name = document.getElementById('contact-name').value;
    const email = document.getElementById('contact-email').value;
    const message = document.getElementById('contact-message').value;

    if (!name || !email || !message) {
        showToast('Please fill in all fields');
        return;
    }

    // Save to localStorage
    const contact = { name, email, message, timestamp: new Date().toISOString() };
    const contacts = JSON.parse(localStorage.getItem('contacts') || '[]');
    contacts.push(contact);
    localStorage.setItem('contacts', JSON.stringify(contacts));

    // Show success
    document.getElementById('contact-form').style.display = 'none';
    document.getElementById('contact-success').style.display = 'block';

    showToast('Message sent successfully!');

    setTimeout(() => {
        document.getElementById('contact-form').style.display = 'block';
        document.getElementById('contact-success').style.display = 'none';
        document.getElementById('contact-form').reset();
    }, 3000);
}

function submitFeedback(e) {
    e.preventDefault();

    const name = document.getElementById('feedback-name').value;
    const message = document.getElementById('feedback-message').value;

    if (!name || !message) {
        showToast('Please fill in all fields');
        return;
    }

    // Save to localStorage
    const feedback = { name, message, timestamp: new Date().toISOString() };
    const feedbacks = JSON.parse(localStorage.getItem('feedbacks') || '[]');
    feedbacks.push(feedback);
    localStorage.setItem('feedbacks', JSON.stringify(feedbacks));

    showToast('Thank you for your feedback!');
    document.getElementById('feedback-form').reset();
}

// ==================== UTILITY FUNCTIONS ====================
function showToast(message) {
    const existingToast = document.querySelector('.toast');
    if (existingToast) existingToast.remove();

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #ff5722;
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        z-index: 10000;
        animation: slideInUp 0.3s ease;
    `;
    document.body.appendChild(toast);

    setTimeout(() => toast.remove(), 3000);
}

function openLightbox(src) {
    const lightbox = document.getElementById('lightbox');
    if (lightbox) {
        const img = document.getElementById('lightbox-img');
        img.src = src;
        lightbox.style.display = 'flex';
    }
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    if (lightbox) {
        lightbox.style.display = 'none';
    }
}

function setMinimumDate() {
    const dateInput = document.getElementById('res-date');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.min = today;
    }
}

function acceptCookies() {
    const cookieBox = document.getElementById('cookie-box');
    if (cookieBox) cookieBox.style.display = 'none';
    localStorage.setItem('cookiesAccepted', 'true');
}

function subscribeNewsletter(e) {
    e.preventDefault();
    const email = e.target.querySelector('input[type="email"]').value;
    if (email) {
        showToast('Thanks for subscribing!');
        e.target.reset();
    }
}

// ==================== INITIAL SETUP ====================
updateCartDisplay();
